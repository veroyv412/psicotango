    <script type="text/javascript">
        var ajaxurl = '<?php echo site_url('c=admin&m=ajax'); ?>';
    </script>
</body>
</html>