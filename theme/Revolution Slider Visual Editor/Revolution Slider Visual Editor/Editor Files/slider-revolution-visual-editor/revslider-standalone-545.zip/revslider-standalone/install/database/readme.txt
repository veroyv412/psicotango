The Installer uses the XML files to install or migrate the DB data.

SQL files (.sql) are provided as support and can be used for manual migration.
Each SQL file contains the same data as the XML one.

